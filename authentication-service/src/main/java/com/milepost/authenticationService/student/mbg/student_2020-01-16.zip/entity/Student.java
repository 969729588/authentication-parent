package com.milepost.authenticationService.student.entity;

import java.io.Serializable;
import java.util.Date;

public class Student implements Serializable {
    /**
     * student.ID
     * 
     *
     * @mbggenerated
     */
    private String id;

    /**
     * student.NAME
     * 姓名
     *
     * @mbggenerated
     */
    private String name;

    /**
     * student.STU_NO
     * 学号
     *
     * @mbggenerated
     */
    private String stuNo;

    /**
     * student.BIRTH
     * 出生日期
     *
     * @mbggenerated
     */
    private Date birth;

    /**
     * student.SCORE
     * 分数
     *
     * @mbggenerated
     */
    private Float score;

    /**
     * student.CLASSES_ID
     * 班级id
     *
     * @mbggenerated
     */
    private String classesId;

    /**
     * student.REMARK
     * 评价
     *
     * @mbggenerated
     */
    private String remark;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getStuNo() {
        return stuNo;
    }

    public void setStuNo(String stuNo) {
        this.stuNo = stuNo == null ? null : stuNo.trim();
    }

    public Date getBirth() {
        return birth;
    }

    public void setBirth(Date birth) {
        this.birth = birth;
    }

    public Float getScore() {
        return score;
    }

    public void setScore(Float score) {
        this.score = score;
    }

    public String getClassesId() {
        return classesId;
    }

    public void setClassesId(String classesId) {
        this.classesId = classesId == null ? null : classesId.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", name=").append(name);
        sb.append(", stuNo=").append(stuNo);
        sb.append(", birth=").append(birth);
        sb.append(", score=").append(score);
        sb.append(", classesId=").append(classesId);
        sb.append(", remark=").append(remark);
        sb.append("]");
        return sb.toString();
    }
}